#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <arpa/inet.h>  // to use inet_add get Client IP & Port
#include <unistd.h>     // to use write() oder to write data in socket
#include <string.h>     // to use strlen()
#include <pthread.h>
#include <errno.h>
#include <ifaddrs.h>
#include <netdb.h>

#include "cJSON.h"
#include "debug.h"
#include "odroid_tcp_server.h"

void print_usage(FILE *f);

int main(int argc, char * const argv[])
{
	int ret;
	int tcp_port = 4001;
	int opt;

	while ((opt = getopt(argc, argv, "p:h")) != -1) {
		switch (opt) {
		case 'p': tcp_port = atoi(optarg); break;
		case 'h': print_usage(stdout); exit(0);
		default:
			print_usage(stderr);
			exit(0);
		}
	}
	INF("Listen on port: %d", tcp_port);

	ret = tcp_server_init(tcp_port);
	if (ret != TCP_SRV_OK) {
		ERR("TCP Server Init failed");
		exit(0);
	}
	INF("TCP Server finished");

	return 0;
}

void print_usage(FILE *f)
{
	fprintf(f, "Steinsvik Oroid Program\n");
}