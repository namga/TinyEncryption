#ifndef __WB_DEBUG_H__
#define __WB_DEBUG_H__
#ifdef __cplusplus
extern "C" {
#endif
#include <errno.h>
#include <stdio.h>

#define VERBOSE_NONE  (0)
#define VERBOSE_ERROR (1)
#define VERBOSE_INFO  (2)
#define VERBOSE_DEBUG (3)

#ifndef PRINT_LEVEL
#define PRINT_LEVEL VERBOSE_NONE
#endif /* PRINT_LEVEL */

#define DBG_BASE(fmt,args...)    do{printf("%04d:%20s: DBG " fmt "\n", __LINE__, __FUNCTION__, ##args);}while(0)
#define INF_BASE(fmt,args...)    do{printf("%04d:%20s: INF " fmt "\n", __LINE__, __FUNCTION__, ##args);}while(0)
#define ERR_BASE(fmt,args...)    do{printf("%04d:%20s: ERR " fmt "\n", __LINE__, __FUNCTION__, ##args);}while(0)
#define ERR_NO_BASE(fmt,args...) do{printf("%04d:%20s: ERR " fmt " errno=%d\n", __LINE__, __FUNCTION__, ##args, errno);}while(0)

#if PRINT_LEVEL >= VERBOSE_DEBUG
#define DBG(fmt,args...) DBG_BASE(fmt, ##args)
#define DBG_HEX_DUMP(_buf,_len) do{ \
                           printf("%04d:%20s: DBG ", __LINE__, __FUNCTION__); \
                           print_hex_arr(_buf,_len); \
                           printf("\n");}while(0)
#else
#define DBG(fmt,args...)
#define DBG_HEX_DUMP(_buf,_len)
#endif /* PRINT_LEVEL >= VERBOSE_DEBUG */

#if PRINT_LEVEL >= VERBOSE_INFO
#define INF(fmt,args...) INF_BASE(fmt, ##args)
#else
#define INF(fmt,args...)
#endif /* PRINT_LEVEL >= VERBOSE_INFO */

#if PRINT_LEVEL >= VERBOSE_ERROR
#define ERR(fmt,args...) ERR_BASE(fmt, ##args)
#else
#define ERR(fmt,args...)
#endif /* PRINT_LEVEL >= VERBOSE_INFO */

#if PRINT_LEVEL >= VERBOSE_ERROR
#define ERR_NO(fmt,args...) ERR_NO_BASE(fmt, ##args)
#else
#define ERR_NO(fmt,args...)
#endif /* PRINT_LEVEL >= VERBOSE_INFO */

///////////////////////////// PROTOTYPES //////////////////////////////////////////////////////////
void print_hex_arr(void *arr, int length);

#ifdef __cplusplus
}
#endif
#endif /* __WB_DEBUG_H__ */
