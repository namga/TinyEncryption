#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <arpa/inet.h>  // to use inet_add get Client IP & Port
#include <unistd.h>     // to use write() oder to write data in socket
#include <string.h>     // to use strlen()
#include <pthread.h>
#include <errno.h>
#include <ifaddrs.h>
#include <netdb.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include "debug.h"

#include "odroid_tcp_server.h"

#define EVENT_TIMEOUT_MS 100
#define IDLE_TIMEOUT_S 30

static int s_client_sock_fds[MAX_CLIENTS] = {0};
static int s_client_connected = 0;
static int s_server_sock = -1;
static int s_is_sock_stop = 0;
static uint8_t s_recv_buf[2048];
static int s_socket_busy = -1;
static int s_timeout_counts[MAX_CLIENTS] = {0};

static int s_chk_msg_timeout(void);
static int s_disconnect_client(int sockfd);
static int s_build_fd_sets(fd_set *set, struct timeval *timeout, int *max_fd);
static int s_process_event(void);
static int s_recv_cli_msg(int sockfd);
int proto_process_header(uint8_t *buf);


/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            tcp_server_init
 *
 * DESC:
 *
 * PARAM:           int port
 *
 *
 * RETURN:          int
 *
 **********************************************************************************************************
 */
int tcp_server_init(int port)
{
	int opt = 1;
	int ret;
	struct sockaddr_in server;
	int client_index;

	for (client_index = 0; client_index < MAX_CLIENTS; ++client_index) {
		s_client_sock_fds[client_index] = -1;
		s_timeout_counts[client_index] = 0;
	}
	s_client_connected = 0;
	s_is_sock_stop = 0;

	// create socket
	s_server_sock = socket(AF_INET, SOCK_STREAM, 0);

	if( s_server_sock < 0 )
	{
		ERR_NO("Can't create server socket");
		goto lb_sockerr;
	}
	DBG("Server socket created %d", s_server_sock);

	if(( setsockopt(s_server_sock, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt))) < 0 )
	{
		ERR_NO("Set socket option REUSEADDR.");
		goto lb_setuperr;
	}

	// socket addr_in structure
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons(port);

	// bind soket
	if(bind(s_server_sock, (struct sockaddr*)& server, sizeof(struct sockaddr)) < 0)
	{
		ERR_NO("Server socket bind failed");
		goto lb_setuperr;
	}

	//try to specify maximum of 3 pending connections for the master socket
	if (listen(s_server_sock, MAX_CLIENTS) < 0) {
		ERR_NO("Start listen on server socket failed");
		goto lb_setuperr;
	}
	INF("TCP Server started on port %d", port);

	while (!s_is_sock_stop) {
		s_chk_msg_timeout();		//check timeout
		ret = s_process_event();
		if (TCP_SRV_TIMEOUT == ret) {
			continue;
		}
	}

	return TCP_SRV_OK;
	goto lb_setuperr;

lb_setuperr:
	close(s_server_sock);
lb_sockerr:
	return TCP_SRV_ERR;
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            tcp_server_deinit
 *
 * DESC:
 *
 * PARAM:           none
 *
 *
 * RETURN:          int
 *
 **********************************************************************************************************
 */
int tcp_server_deinit(void)
{
	return TCP_SRV_OK;
}


/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            s_chk_msg_timeout
 *
 * DESC:
 *
 * PARAM:           none
 *
 *
 * RETURN:          int
 *
 **********************************************************************************************************
 */
static int s_chk_msg_timeout(void)
{
	int i;
	int fd;

	for (i = 0; i < MAX_CLIENTS; ++i) {
		fd = s_client_sock_fds[i];
		if (fd <= 0) {
			continue;
		}

		if (fd != s_socket_busy) {
			s_timeout_counts[i] ++;

			if (s_timeout_counts[i] >= ((IDLE_TIMEOUT_S * 1000) / EVENT_TIMEOUT_MS) + 3) {
				ERR("Client %d:%d does not recv message inside %ds. Quit", i, fd, IDLE_TIMEOUT_S);

				s_disconnect_client(fd);
			}
		}
	}

	return TCP_SRV_OK;
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            s_chk_msg_timeout
 *
 * DESC:
 *
 * PARAM:           none
 *
 *
 * RETURN:          int
 *
 **********************************************************************************************************
 */

static int s_disconnect_client(int sockfd)
{
	int i;

	if (sockfd <= 0) {
		return TCP_SRV_ERR;
	}

	for (i = 0; i < MAX_CLIENTS; ++i) {
		if (sockfd == s_client_sock_fds[i]) {
			close(sockfd);
			s_client_connected --;
			s_client_sock_fds[i] = -1;
			INF("client %d closed, now %d/%d connections", sockfd, s_client_connected, MAX_CLIENTS);
			break;
		}
	}

	return TCP_SRV_OK;
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            s_chk_msg_timeout
 *
 * DESC:
 *
 * PARAM:           none
 *
 *
 * RETURN:          int
 *
 **********************************************************************************************************
 */
static int s_process_event(void)
{
	fd_set readfds;
	fd_set errfds;
	struct timeval timeout;
	int max_fd_no = 0;
	int ret;
	int i;
	int fd;

	struct sockaddr_in client;
	int socket_size = sizeof(struct sockaddr_in);

	ret = s_build_fd_sets(&readfds, &timeout, &max_fd_no);
	if (TCP_SRV_OK != ret) {
		ERR("Build fd sets failed");
		return TCP_SRV_ERR;
	}

	ret = s_build_fd_sets(&errfds, NULL, NULL);

	ret = select( max_fd_no + 1 , &readfds , NULL , &errfds , &timeout);
	if (ret == 0) {
		return TCP_SRV_TIMEOUT;
	} else if (ret < 0) {
		return TCP_SRV_ERR;
	}

	// Have events, process them
	if (FD_ISSET(s_server_sock, &readfds)) {
		// Event on master socket, accept the client connection

		fd = accept(s_server_sock, (struct sockaddr *)&client, (socklen_t*)&socket_size);
		if (fd < 0) {
			ERR_NO("Accept new client connection failed");
		} else {
			INF("New client connection: fd: %d, url: %s:%d", fd, inet_ntoa(client.sin_addr) , ntohs(client.sin_port));
			// Check if number of connections is max
			if (s_client_connected >= MAX_CLIENTS) {
				// no connection slot available. close connection
				INF("%d/%d connection created, close this new connection", s_client_connected, MAX_CLIENTS);
				close(fd);
			} else {
				s_client_connected ++;
				// Find client slot
				for (i = 0; i < MAX_CLIENTS; ++i) {
					if (s_client_sock_fds[i] < 0) {
						s_client_sock_fds[i] = fd;
						s_timeout_counts[i] = 0;
						break;
					}
				}
				INF("Connection added into list at %d, now %d/%d connections", i, s_client_connected, MAX_CLIENTS);
			}
		}
	}

	// Checkif any error occurs on client sockets
	for (i = 0; i < MAX_CLIENTS; ++i) {
		fd = s_client_sock_fds[i];
		if (fd <= 0) {
			continue;
		}
		if (FD_ISSET(fd, &errfds)) {
			INF("Has problem on client socket %d at %d. CLOSE IT", fd, i);
			// TODO: terminate the current processing of this socket

			// free socket
			s_disconnect_client(fd);
		}
	}

	// Check if have any data on client sockets
	ret = TCP_SRV_OK;
	for (i = 0; i < MAX_CLIENTS; ++i) {
		fd = s_client_sock_fds[i];
		if (fd <= 0) {
			continue;
		}
		if (FD_ISSET(fd, &readfds)) {
			// Has data
			INF("Has data on client socket %d at %d.", fd, i);

			if (s_socket_busy > 0) {
				// has busy request
				usleep(EVENT_TIMEOUT_MS * 1000);
				return TCP_SRV_OK;
			}
			// process data
			s_timeout_counts[i] = 0;
			int tmp = s_recv_cli_msg(fd);
			if (TCP_SRV_NOT_SVK == tmp) {
				tmp = s_disconnect_client(fd);
			}
			if (tmp != TCP_SRV_OK) {
				ERR("Process command on socket %d failed", fd);
				tmp = s_disconnect_client(fd);
				s_socket_busy = -1;
				ret = TCP_SRV_ERR;
			}else {
				// Request processed
				INF("Request executed. Quit");
				tmp = s_disconnect_client(fd);
				s_socket_busy = -1;
			}
		}
	}

	return ret;
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            s_chk_msg_timeout
 *
 * DESC:
 *
 * PARAM:           none
 *
 *
 * RETURN:          int
 *
 **********************************************************************************************************
 */
static int s_build_fd_sets(fd_set *set, struct timeval *timeout, int *max_fd)
{
	int i;
	int max = s_server_sock;
	int tmp;

	if (timeout) {
		//set timeout 100ms
		tmp = EVENT_TIMEOUT_MS / 1000;
		timeout->tv_sec = tmp;
		timeout->tv_usec = (EVENT_TIMEOUT_MS - (tmp * 1000)) * 1000;
	}

	// Set fd_set
	FD_ZERO(set);
	FD_SET(s_server_sock, set);

	for (i = 0; i < MAX_CLIENTS; ++i) {
		tmp = s_client_sock_fds[i];
		if (tmp > 0) {
			FD_SET(tmp, set);
		}

		if (tmp > max) {
			max = tmp;
		}
	}

	if (max_fd) {
		*max_fd = max;
	}

	return TCP_SRV_OK;
}


static int s_recv_cli_msg(int sockfd)
{
	int len;
	int ret;

	struct timeval timewait;

	// Mark as busying state
	s_socket_busy = sockfd;

	// Sleep 100ms, just to avoid that the data is still comming
	usleep(100000);

	// receive HEADER only
	len = recv(sockfd , s_recv_buf, 4, 0);
	DBG("header socket length: %d", len);

	if (len < 4) {
		ERR("client %d, only %d/%d header received --> disconnected", sockfd, len, 4);
		goto lb_not_svk;
	}

	printf("%s\n",s_recv_buf );
	

	timewait.tv_sec = len/5;			//time wait to received data = lenght/5
	timewait.tv_usec = (timewait.tv_sec) * 1000;
	setsockopt (sockfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&timewait, sizeof(timewait));

	ret = recv(sockfd, s_recv_buf + 4, len, 0);
	DBG("%d/%d bytes received. Process it", ret, len);
	

	s_socket_busy = -1;

	return TCP_SRV_OK;

lb_not_svk:
	s_socket_busy = -1;
	return TCP_SRV_NOT_SVK;
}
