#ifndef __ODROID_TCP_SERVER_H__
#define __ODROID_TCP_SERVER_H__ 1

/**! Maximum number of concurrent clients */
#define MAX_CLIENTS		5

typedef enum {
	TCP_SRV_OK = 0,
	TCP_SRV_TIMEOUT,
	TCP_SRV_NOT_SVK,
	TCP_SRV_ERR
}tcp_server_err_t;

int tcp_server_init(int port);

int tcp_server_deinit(void);

#endif /* __TCP_SERVER_H__ */