#ifndef __ODROID_COMAND_H__
#define __ODROID_COMAND_H__ 1


int odroid_command_init(int port);

int odroid_command_send(void);

#endif /* __ODROID_COMAND_H__ */