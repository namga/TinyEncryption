#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <arpa/inet.h>  // to use inet_add get Client IP & Port
#include <unistd.h>     // to use write() oder to write data in socket
#include <string.h>     // to use strlen()
#include <pthread.h>
#include <errno.h>
#include <ifaddrs.h>
#include <netdb.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include "debug.h"

#include "odroid_read_command.h"

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
int odroid_command_init(int port)
{

}


/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
int odroid_command_send(void)
{

}