#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <arpa/inet.h>  // to use inet_add get Client IP & Port
#include <unistd.h>     // to use write() oder to write data in socket
#include <string.h>     // to use strlen()
#include <pthread.h>
#include <errno.h>
#include <ifaddrs.h>
#include <netdb.h>
#include <signal.h>

#include "cJSON.h"
#include "debug.h"

#include <termios.h>
#include <fcntl.h>

#define BAUDRATE B115200
#define MODEMDEVICE "/dev/ttyS1"

#define ORIGINAL_DEPTH 	0
#define MAX_DEPTH 		100

uint8_t u_readSensor[5] = {0x05, 0x00, 0x52, 0x44, 0x64};
uint8_t u_winchUp[7] 	= {0xAA, 0x05, 0x20, 0x00, 0x00, 0x00, 0x30};
uint8_t u_winchDown[7] 	= {0xAA, 0x05, 0x40, 0x00, 0x00, 0x00, 0x10};

static int depth_interval	= 0;
static int sequence_time 	= 0;
static int current_depth 	= 0;
static int limit_time 		= 0;
static int resp_buff[1024] 	= {0};

/* prototypes */
void init_sigaction(void);
void init_time(void);
void timeout_info(int signo);
void read_data_sensor();
void winch_to_new_depth(int depth);
void winch_to_original_depth();
void send_To_Serial(uint8_t *u_buffer_data, uint8_t data_size);
void read_From_Serial();

int check_depth_not_reachead(int depth);
int start_AutoLoginMode(int dept, int timeout);


/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            main
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
int main(int argc, char * const argv[])
{
 	//start_AutoLoginMode(5, 30);

 	read_From_Serial();

    return 0;
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            open_SerialPort
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
void send_To_Serial(uint8_t *u_buffer_data, uint8_t data_size)
{
	int fd;

   	struct termios newtio; 

   	fd = open( MODEMDEVICE, O_RDWR | O_NOCTTY | O_NONBLOCK );

	/* Error Checking */
   	if(fd == -1)
   	{
        printf("\n  Error! in Opening ttyS1 \n");
        perror(MODEMDEVICE);
   	}
    else
        printf("\n  ttyS1 Opened Successfully \n");

   	memset( &newtio, 0, sizeof(newtio) );

   	newtio.c_cflag = BAUDRATE;   // 115200 
   	newtio.c_cflag &= ~PARENB;  /* Disables the Parity Enable bit(PARENB),So No Parity   */
	newtio.c_cflag &= ~CSTOPB;  /* CSTOPB = 2 Stop bits,here it is cleared so 1 Stop bit */
	newtio.c_cflag &= ~CSIZE;	/* Clears the mask for setting the data size             */
	newtio.c_cflag &= ~CRTSCTS; /* No Hardware flow Control                         */
   	newtio.c_cflag |= CS8;      //  8bit 
   	newtio.c_cflag |= CLOCAL;   // 
   	newtio.c_cflag |= CREAD;    // 
   	newtio.c_iflag = 0;         // parity 
   	newtio.c_oflag = 0;
   	newtio.c_lflag = 0;
   	newtio.c_cc[VTIME] = 0; 
   	newtio.c_cc[VMIN] = 1; 

   	tcflush (fd, TCIFLUSH );
   	tcsetattr(fd, TCSANOW, &newtio );
   
   	int rc = write( fd, u_buffer_data, data_size);
   	if(rc < 0)
   		printf("\n  Write Faile \n");
   	else
        printf("\n  Write Successfully \n");

   	close( fd);
}

void read_From_Serial()
{
	
    int fd;
    int wait_flag = 1;

   	struct termios newtio; 

   	fd = open( MODEMDEVICE, O_RDWR | O_NOCTTY | O_NONBLOCK );

	/* Error Checking */
   	if(fd == -1)
   	{
        printf("\n  Error! in Opening ttyS1 \n");
        perror(MODEMDEVICE);
   	}
    else
        printf("\n  ttyS1 Opened Successfully \n");

   	memset( &newtio, 0, sizeof(newtio) );

   	newtio.c_cflag = BAUDRATE;   // 115200 
   	newtio.c_cflag &= ~PARENB;  /* Disables the Parity Enable bit(PARENB),So No Parity   */
	newtio.c_cflag &= ~CSTOPB;  /* CSTOPB = 2 Stop bits,here it is cleared so 1 Stop bit */
	newtio.c_cflag &= ~CSIZE;	/* Clears the mask for setting the data size             */
	newtio.c_cflag &= ~CRTSCTS; /* No Hardware flow Control                         */
   	newtio.c_cflag |= CS8;      //  8bit 
   	newtio.c_cflag |= CLOCAL;   // 
   	newtio.c_cflag |= CREAD;    // 
   	newtio.c_iflag = 0;         // parity 
   	newtio.c_oflag = 0;
   	newtio.c_lflag = 0;
   	newtio.c_cc[VTIME] = 0; 
   	newtio.c_cc[VMIN] = 1; 

   	tcflush (fd, TCIFLUSH );
   	tcsetattr(fd, TCSANOW, &newtio );
   
   	while(1)
   	{
   		if(wait_flag = 1)
   		{
   			int rc = read( fd, resp_buff, 255);
   			if(rc < 0)
   			{
   				printf("\n  Read fail- Wait data \n");
   			}
   			else
   			{
        		printf("\n Read successfully: %s \n", resp_buff);

        		wait_flag = 0;
        		break;
   			}
   		}
   	}
   	

   	close( fd);
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
int start_AutoLoginMode(int dept, int timeout)
{
	depth_interval = dept;
	sequence_time = timeout;

	//read sensor to get original depth
	read_data_sensor();

	init_sigaction();
    init_time();
    printf("Start timer 30 seconds for autologin.\n");

    while(1);
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
void read_data_sensor()
{
	//send command read camera depth (m)

	send_To_Serial(u_readSensor, sizeof(u_readSensor));
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
void winch_to_new_depth(int depth)
{
	current_depth = current_depth + depth;
	//send command winch down camera depth (m)

	send_To_Serial(u_winchDown, sizeof(u_winchDown));

	DBG("new dept is %d",current_depth);
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
void winch_to_original_depth()
{
	current_depth = ORIGINAL_DEPTH;

	send_To_Serial(u_winchUp, sizeof(u_winchUp));
    printf("=== End of Program  ===\n");

	//send command winch up camera original (m)
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
int check_depth_not_reachead(int depth)
{
	if(depth >= MAX_DEPTH)
		return -1;
	else
		return 0;
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:            
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
void timeout_info(int signo)
{
   	if(limit_time == 0)
   	{
   		int depth_not_reached = 0;
   	
   		do
   		{
   			sleep(1);
   			depth_not_reached = check_depth_not_reachead(current_depth);
   			winch_to_new_depth(depth_interval);

   			sleep(1);
   			// read data sensor here
   			read_data_sensor();
   		}
   		while (depth_not_reached == 0);
   	
   		printf("Sorry, max depth reached.\n");
	
		winch_to_original_depth();
   	
    	limit_time = sequence_time;
   		init_sigaction();
    	init_time();
       
   }
   printf("only %d senconds left.\n", limit_time--);
}

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:       init sigaction     
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
void init_sigaction(void)
{
    struct sigaction act;

    act.sa_handler = timeout_info;
    act.sa_flags   = 0;
    sigemptyset(&act.sa_mask);
    sigaction(SIGPROF, &act, NULL);
} 

/**********************************************************************************************************
 *
 * LAST UPDATE:     
 *
 * FUNC:       init_time     
 *
 * DESC:
 *
 * PARAM:           
 *
 *
 * RETURN:          
 *
 **********************************************************************************************************
 */
void init_time(void)
{
    struct itimerval val;

    val.it_value.tv_sec = 1;
    val.it_value.tv_usec = 0;
    val.it_interval = val.it_value;
    setitimer(ITIMER_PROF, &val, NULL);
}


