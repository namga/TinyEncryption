#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QStringList>
#include <QTextStream>
#include "commandstock.h"
#include <QFileDialog>
#include <QBuffer>
#include <QtEndian>
#include <QTimer>

namespace Ui {
class MainWindow;
}

class MySerial;
class ReadCommand;
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit        MainWindow(QWidget *parent = 0);
                    ~MainWindow();
    void            writeCommand(CommandType *cmd, CommandEnum _typeENUM);
    void            writeData(QByteArray data);
    QString         converString(QByteArray qArr);
    bool            sendPINGCommand();
    QByteArray      get32ByteFromData(QByteArray data, uint32_t index);

    uint16_t        calCRC16(const uint8_t *src, uint32_t length);
    void            updateCRCByte(CommandType *cmd);
    void            updateSizeData2Send(CommandType *cmd);
    void            sendACK();
    void            init();

    QByteArray      data;
    uint32_t        block_data;
    uint32_t        size_block_final;
    uint32_t        _indexBlock;
    int             _iGetParam;
    int             _iValueProcess;
    bool            _bDisconnect;
    QTimer          *timeOut;


private slots:
    void            on_btConnect_clicked();
    void            on_btBrowse_clicked();
    void            on_btReset_clicked();
    void            showData();
    void            pingAgain();
    void            sendOtherCommand();

    void on_btFlash_clicked();

    void on_btClearlog_clicked();

private:

    MySerial        *mySerial;
    ReadCommand     *read;
    CommandType     *cmd;
    CommandEnum     _cmdEnum;
    Ui::MainWindow  *ui;
};

#endif // MAINWINDOW_H
