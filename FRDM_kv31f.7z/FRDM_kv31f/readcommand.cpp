#include "readcommand.h"

ReadCommand::ReadCommand()
{

}


CommandType* ReadCommand::getCommand(CommandEnum cmd)
{
    switch(cmd)
    {
    case PING:
        return &ping;
        break;
    case PROPERTY:
        return &readProperty;
        break;
    case READ_MEMMORY:
        return &readMemmory;
        break;
    case WRITE_MEMMORY:
        return &writeMemmory;
        break;
    case RESET:
        return &reset;
        break;
    case FLASH_ERASE:
        return &flashEraseAll;
        break;
    case FLASH_REGION:
        return &flashEraseRegion;
        break;
    case FLASH_UNSERCURE:
        return &flashEraseUnsecure;
        break;
    default:
        break;
    }

    return nullptr;
}
