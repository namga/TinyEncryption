#include "mainwindow.h"
#include <QApplication>
#include <QSysInfo>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    qSetMessagePattern("%{file}(%{line}): %{message}");

    MainWindow w;
    w.setWindowTitle("FRDM BootFlash V1.0");
    w.setFixedSize(800, 600);
    w.show();

    return a.exec();
}
