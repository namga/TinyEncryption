#include "myserial.h"
#include <QtEndian>

MySerial::MySerial(QObject *parent)
    : QObject(parent)
{
    serial_port = new QSerialPort(this);
    connect(serial_port, SIGNAL(readyRead()), this, SLOT(readData()));
    connect(serial_port, SIGNAL(error(QSerialPort::SerialPortError)), this,
    SLOT(handleError(QSerialPort::SerialPortError)));

    _bResetTmp      = true;
    _bAppendData    = false;
    S_Ping_Packet       = new SPingPacket();
    S_Reset_Packet      = new SResetPacket();
    S_Property_Package  = new SPropertyPacket();
    S_Write_Packet      = new SWritePacket();
}

MySerial::~MySerial()
{
    closeSerialPort();
    delete serial_port;
}

bool MySerial::openSerialPort(QString strPort)
{
    serial_port->setPortName(strPort);
    serial_port->setBaudRate(QSerialPort::Baud115200);
    serial_port->setDataBits(QSerialPort::Data8);
    serial_port->setParity(QSerialPort::NoParity);
    serial_port->setStopBits(QSerialPort::OneStop);
    serial_port->setFlowControl(QSerialPort::NoFlowControl);
    if (serial_port->open(QIODevice::ReadWrite))
    {
        this->showStatusMessage("[INFO] Connected");
        return true;
    }
    else
    {
        this->showStatusMessage(tr("[INFO] Open error"));
        return false;
    }
}

void MySerial::closeSerialPort()
{
    if (serial_port->isOpen())
        serial_port->close();

    this->showStatusMessage(tr("[INFO] Disconnected"));
}


void MySerial::writeData(QByteArray data, CommandEnum eNumTypeCmd)
{
    _TypeENUM = eNumTypeCmd;
    serial_port->write(data);
    serial_port->waitForBytesWritten(3000);

    qDebug() << "SEND:";
    this->showStatusMessage(QString::fromLocal8Bit(data.toHex()));
}

void MySerial::readData()
{
    if(_bResetTmp != false)
    {
        _data_response.clear();
        _bResetTmp = false;
    }
    QByteArray resp = serial_port->readAll();

    if(_bAppendData != false)
    {
        if((_data_response.length() > 1)
                && (_data_response[0] == 0x5a))   // correct startbyte
        {
            this->showStatusMessage("Append correct start byte!!");
            this->showStatusMessage(QString::fromLocal8Bit(_data_response.toHex()));
        }
        else
        {

        }
    }

    if((resp.length() > 1)
            && (resp[0] == 0x5a))   // correct startbyte
    {
        this->showStatusMessage("Normal correct start byte!!");
        if((resp.length() == 2) &&
                (resp[1] = 0xa1))
        {

        }
        else
        {

        }
    }
    else    //data rash
    {

    }

        qDebug() << "RESPONSE final:";
        this->showStatusMessage(QString::fromLocal8Bit(_data_response.toHex()));

//    qDebug() << "RESPONSE:";
//    this->showStatusMessage(QString::fromLocal8Bit(resp.toHex()));

    switch (_TypeENUM)
    {
//    case PROPERTY:
//    {
//        _data_response.append(resp);
//        S_Property_Package->u_lenght = _data_response.length();
//        qDebug() << "lenght:" <<S_Property_Package->u_lenght;
//        qDebug() << "RESPONSE:" << _data_response;

//        if(S_Property_Package->u_lenght  ==  20)
//        {
//            S_Property_Package->S_ACK = new SACKStruct();
//            S_Property_Package->S_ACK->u_start_byte     = *(_data_response.data());
//            S_Property_Package->S_ACK->u_packet_type    = *(_data_response.data() + 1);

//            S_Property_Package->S_Property = new SPropertyStruct();
//            S_Property_Package->S_Property->u_start_byte = *(_data_response.data() + 2);
//            S_Property_Package->S_Property->u_packet_type = *(_data_response.data() + 3);

//            S_Property_Package->S_Property->u_byte_lenght = (uint16_t)*(_data_response.data() + 5) & 0x00FF;
//            S_Property_Package->S_Property->u_byte_lenght = (uint16_t)(S_Property_Package->S_Property->u_byte_lenght << 8)
//                                                                | (*(_data_response.data() + 4) & 0x00FF);
//            S_Property_Package->S_Property->u_crc =  (uint16_t)*(_data_response.data() + 7) & 0x00FF;
//            S_Property_Package->S_Property->u_crc =  (uint16_t)(S_Property_Package->S_Property->u_crc << 8)
//                                                    | (*(_data_response.data() + 6) & 0x00FF);

//            S_Property_Package->S_Property->u_command_tag   = *(_data_response.data() + 8);
//            S_Property_Package->S_Property->u_flags         = *(_data_response.data() + 9);
//            S_Property_Package->S_Property->u_reserved      = *(_data_response.data() + 10);
//            S_Property_Package->S_Property->u_param_count   = *(_data_response.data() + 11);


//            S_Property_Package->S_Property->u_status  = (uint32_t)*(_data_response.data() + 15) & 0x000000FF;
//            S_Property_Package->S_Property->u_status  = (uint32_t)(S_Property_Package->S_Property->u_status << 8)
//                                                        | (*(_data_response.data() + 14) & 0x000000FF);
//            S_Property_Package->S_Property->u_status  = (uint32_t)(S_Property_Package->S_Property->u_status << 16)
//                                                        | (*(_data_response.data() + 13) & 0x000000FF);
//            S_Property_Package->S_Property->u_status  = (uint32_t)(S_Property_Package->S_Property->u_status << 24)
//                                                        | (*(_data_response.data() + 12) & 0x000000FF);

//            S_Property_Package->S_Property->u_property_value  = (uint32_t)*(_data_response.data() + 16) & 0x000000FF;
//            S_Property_Package->S_Property->u_property_value  = (uint32_t)(S_Property_Package->S_Property->u_property_value << 8)
//                                                                | (*(_data_response.data() + 17) & 0x000000FF);
//            S_Property_Package->S_Property->u_property_value  = (uint32_t)(S_Property_Package->S_Property->u_property_value << 8)
//                                                                | (*(_data_response.data() + 18) & 0x000000FF);
//            S_Property_Package->S_Property->u_property_value  = (uint32_t)(S_Property_Package->S_Property->u_property_value << 8)
//                                                                | (*(_data_response.data() + 19) & 0x000000FF);


//            qDebug("---- u_byte_lenght: %04x", S_Property_Package->S_Property->u_byte_lenght);
//            qDebug("---- u_crc: %04x", S_Property_Package->S_Property->u_crc);
//            qDebug("---- u_property_value: %08x", S_Property_Package->S_Property->u_property_value);

//            emit completeRead();
//        }
//    }
//        break;
    case PING:
    {
        qDebug() << "[INFO] Case PING, lenght = " << resp.length();

        S_Ping_Packet->u_lenght = resp.length();
        S_Ping_Packet->S_Ping = new SPingStruct();
        S_Ping_Packet->S_Ping->u_start_byte  = *(resp.data());
        S_Ping_Packet->S_Ping->u_resp_code   = *(resp.data() + 1);
        S_Ping_Packet->S_Ping->u_pro_bugfix  = *(resp.data() + 2);
        S_Ping_Packet->S_Ping->u_pro_minor   = *(resp.data() + 3);
        S_Ping_Packet->S_Ping->u_pro_major   = *(resp.data() + 4);
        S_Ping_Packet->S_Ping->u_pro_name    = *(resp.data() + 5);

        S_Ping_Packet->S_Ping->u_option      = (uint16_t)*(resp.data() + 7) & 0x00FF;
        S_Ping_Packet->S_Ping->u_option      = (uint16_t)(S_Ping_Packet->S_Ping->u_option << 8) | (*(resp.data() + 6) & 0x00FF);

        S_Ping_Packet->S_Ping->u_crc         = (uint16_t)(*(resp.data() + 9) & 0x00FF);
        S_Ping_Packet->S_Ping->u_crc         = (uint16_t)(S_Ping_Packet->S_Ping->u_crc << 8) | (*(resp.data() + 8) & 0x00FF);

        qDebug("---- u_option: %04x", S_Ping_Packet->S_Ping->u_option);
        qDebug("---- u_crc: %04x", S_Ping_Packet->S_Ping->u_crc);

        emit completeRead();
    }
        break;
    case RESET:
    {
          qDebug() << "[INFO] Case RESET, lenght = " << resp.length();
          S_Reset_Packet->u_lenght = resp.length();
          S_Reset_Packet->S_ACK = new SACKStruct();
          S_Reset_Packet->S_ACK->u_start_byte   = *(resp.data());
          S_Reset_Packet->S_ACK->u_packet_type  = *(resp.data() +1);

          S_Reset_Packet->S_Reset = new SResetStruct();
          S_Reset_Packet->S_Reset->u_start_byte     = *(resp.data() +2);
          S_Reset_Packet->S_Reset->u_packet_type    = *(resp.data() +3);

          S_Reset_Packet->S_Reset->u_byte_lenght    = (uint16_t)(*(resp.data() + 5) & 0x00FF);
          S_Reset_Packet->S_Reset->u_byte_lenght    = (uint16_t)(S_Reset_Packet->S_Reset->u_byte_lenght << 8) | (*(resp.data() + 4) & 0x00FF);

          S_Reset_Packet->S_Reset->u_crc            = (uint16_t)(*(resp.data() + 7) & 0x00FF);
          S_Reset_Packet->S_Reset->u_crc            = (uint16_t)(S_Reset_Packet->S_Reset->u_crc << 8) | (*(resp.data() + 6) & 0x00FF);

          S_Reset_Packet->S_Reset->u_command_tag    = *(resp.data() +8);
          S_Reset_Packet->S_Reset->u_flags          = *(resp.data() +9);
          S_Reset_Packet->S_Reset->u_reserved       = *(resp.data() +10);
          S_Reset_Packet->S_Reset->u_param_count    = *(resp.data() +11);

          qDebug("---- u_option: %04x", S_Reset_Packet->S_Reset->u_byte_lenght);
          qDebug("---- u_crc: %04x", S_Reset_Packet->S_Reset->u_crc);

          emit completeRead();
    }
        break;
    case FLASH_ERASE:
    {
        emit completeRead();
    }
        break;
    case FLASH_REGION:
    {
        _data_response.append(resp);
        if(_data_response.length() == 20)
        {
            this->showStatusMessage(QString::fromLocal8Bit(_data_response.toHex()));
            emit completeRead();
        }
    }
        break;
    case WRITE_MEMMORY:
    {
        _data_response.append(resp);
        if(_data_response.length() == 20)
        {
            this->showStatusMessage(QString::fromLocal8Bit(_data_response.toHex()));
            emit completeRead();
        }
    }
        break;
    case SEND_DATA:
    {
       if( resp.length() < 2)
       {
           _data_response.append(resp);
           qDebug() << "WAIT";
           this->showStatusMessage(QString::fromLocal8Bit(_data_response.toHex()));

           if(_data_response.length() == 2)
           {
               if(_data_response[1] == 0xa1)
               {
                   qDebug() << "ACK";
                   emit completeRead();
               }
               if(_data_response[1] == 0xa3)
               {
                   qDebug() << "0xa3";
               }

               if(_data_response[1] == 0xa4)
               {
                   qDebug() << "0xa4";
               }
           }
           else
           {
                this->showStatusMessage(QString::fromLocal8Bit(_data_response.toHex()));
           }
       }
       else
       {
           if(resp.length() == 2)
           {
               if(resp[1] == 0xa1)
               {
                   qDebug() << "ACK";
                   emit completeRead();
               }
               if(resp[1] == 0xa3)
               {
                    qDebug() << "0xa3";
               }

               if(resp[1] == 0xa4)
               {
                    qDebug() << "0xa4";
               }
           }
           else
           {
               if(resp[1] =0xa3)
               {
                   qDebug() << "RIGHT";
                   resp = resp.right(resp.length() - 2);
                   _data_response.append(resp);
               }
               this->showStatusMessage(QString::fromLocal8Bit(resp.toHex()));
           }
       }
    }
        break;
    default:
        break;
    }
}

void MySerial::handleError(QSerialPort::SerialPortError error)
{
    if (error == QSerialPort::ResourceError) {
        closeSerialPort();
    }
}


void MySerial::showStatusMessage(const QString &message)
{
    qDebug() << message;
}
