#ifndef MYSERIAL_H
#define MYSERIAL_H

#include <QObject>
#include <QSerialPort>
#include <QDebug>
#include "commandstock.h"

class MySerial : public QObject
{
    Q_OBJECT

public:

    QSerialPort     *serial_port;
    CommandEnum     _TypeENUM;
    QByteArray      _data_response;
    bool            _bResetTmp;
    bool            _bAppendData;

    SPingPacket     *S_Ping_Packet;
    SResetPacket    *S_Reset_Packet;
    SPropertyPacket *S_Property_Package;
    SWritePacket    *S_Write_Packet;

    explicit        MySerial(QObject *parent = nullptr);
                    ~MySerial();

    bool            openSerialPort(QString strPort);
    void            closeSerialPort();
    void            writeData(QByteArray data, CommandEnum eNumTypeCmd = NONE);
    void            showStatusMessage(const QString &message);

signals:

    void            completeRead();
    void            continuePING();

public slots:

    void            readData();
    void            handleError(QSerialPort::SerialPortError error);
};

#endif // MYSERIAL_H
