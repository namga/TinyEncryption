#ifndef COMMANDSTOCK_H
#define COMMANDSTOCK_H
#include <qglobal.h>
#include <QByteArray>

typedef struct CommandType
{
    unsigned char command[100];
    quint8 length;

}  CommandType;

//typedef struct ResponseData
//{
//    unsigned char response[100];
//    quint8 length;

//}  ResponseData;

/* ACK STRUCT*/
typedef struct SACKStruct
{
    uint8_t     u_start_byte;
    uint8_t     u_packet_type;
} SACKStruct;

/* PING STRUCT*/
typedef struct SPingStruct
{
    uint8_t     u_start_byte;
    uint8_t     u_resp_code;
    uint8_t     u_pro_bugfix;
    uint8_t     u_pro_minor;
    uint8_t     u_pro_major;
    uint8_t     u_pro_name;
    uint16_t    u_option;
    uint16_t    u_crc;
} SPingStruct;

typedef struct SPingPacket
{
    SPingStruct *S_Ping;
    uint32_t    u_lenght;
} SPingPacket;

/* RESET STRUCT*/
typedef struct SResetStruct
{
    uint8_t     u_start_byte;
    uint8_t     u_packet_type;
    uint16_t    u_byte_lenght;
    uint16_t    u_crc;
    uint8_t     u_command_tag;
    uint8_t     u_flags;
    uint8_t    u_reserved;
    uint8_t    u_param_count;
} SResetStruct;

typedef struct SResetPacket
{
    SACKStruct   *S_ACK;
    SResetStruct *S_Reset;
    uint32_t      u_lenght;
} SResetPacket;

/* VERSION PROPERTY STRUCT*/
typedef struct SPropertyStruct
{
    uint8_t     u_start_byte;
    uint8_t     u_packet_type;
    uint16_t    u_byte_lenght;
    uint16_t    u_crc;
    uint8_t     u_command_tag;
    uint8_t     u_flags;
    uint8_t    u_reserved;
    uint8_t    u_param_count;
    uint32_t    u_status;
    uint32_t    u_property_value;

} SPropertyStruct;

typedef struct SPropertyPacket
{
    SACKStruct      *S_ACK;
    SPropertyStruct *S_Property;
    uint32_t        u_lenght;
} SPropertyPacket;


typedef struct SWriteMemStruct
{
    uint8_t u_start_byte;
    uint8_t u_packet_type;
    uint16_t    u_byte_lenght;
    uint16_t    u_crc;
    uint8_t     u_command_tag;
    uint8_t     u_flags;
    uint8_t     u_reserved;
    uint8_t     u_param_count;
    uint32_t    u_start_addr;
    uint32_t    u_byte_count;

} SWriteMemStruct;

typedef struct SWritePacket
{
    SWriteMemStruct *S_WriteMem;
    uint32_t        u_lenght;
} SWritePacket;


typedef enum CommandEnum
{
    NONE = 0,
    PING,
    PROPERTY,
    READ_MEMMORY,
    WRITE_MEMMORY,
    RESET,
    FLASH_ERASE,
    FLASH_REGION,
    FLASH_UNSERCURE,
    SEND_DATA
}CommandEnum;

#endif // COMMANDSTOCK_H
