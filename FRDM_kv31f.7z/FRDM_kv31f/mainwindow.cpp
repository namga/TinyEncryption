#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "myserial.h"
#include "commandstock.h"
#include "readcommand.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{ 
    this->init();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::init()
{
    mySerial        = NULL;
    read            = NULL;
    _iGetParam      = 0;
    _indexBlock     = 0;
    _iValueProcess  = 0;
    _bDisconnect    = false;
    timeOut         = new QTimer();
    timeOut->setInterval(0.05*1000);
    connect(timeOut,SIGNAL(timeout()), SLOT(sendOtherCommand()));

    ui->setupUi(this);

    foreach (const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts())
    {
        ui->comboBox->addItem(serialPortInfo.portName());
    }
    ui->btConnect->setText("Connect");
}

void MainWindow::on_btBrowse_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, ("Open File"), QDir::currentPath(), ("Binary (*.hex *.bin)"));
    ui->txtDir->setText(fileName);

    QFileInfo fi(fileName);
    QString ext = fi.suffix();
    QFile file(fileName);

    if(!file.open(QIODevice::ReadOnly|QIODevice::Text))
    {
        qDebug() << "[INFO] Can't read file!";
    }
    else
    {
        //case file .bin extension
        if(ext.compare("bin") == 0)
        {
            while(!file.atEnd())
            {
                data = file.readAll();
                block_data = data.length()/32;
                size_block_final = data.length() - (block_data * 32);

                qDebug()<< "--- number block 32:" << block_data << " byte ----total_size:" << data.length() << " byte----size_block_final:" << size_block_final <<" byte";
            }
        }
        else
        {
            ui->listStatus->addItem("Not support!");

//            while(!file.atEnd())
//            {

//            }
        }
    }
    file.close();
}

void MainWindow::on_btFlash_clicked()
{
    qDebug() <<"[INFO] Button Flash Click!";

    //check dir file
    if(ui->txtDir->text() !="")
    {
        if(read != NULL && mySerial != NULL)
        {
            _cmdEnum = FLASH_REGION;
            cmd = read->getCommand(_cmdEnum);
            this->updateCRCByte(cmd);
            this->writeCommand(cmd, _cmdEnum);
            ui->listStatus->addItem("Erase Flash Memmory!");

            mySerial->_bResetTmp = true;
            connect(mySerial, SIGNAL(completeRead()), this, SLOT(showData()));
        }
        else
        {
            ui->listStatus->addItem("Erro! Not connected!");
        }
    }
    else
    {
        ui->listStatus->addItem("Erro! Not dir file detect!");
    }
}

void MainWindow::sendOtherCommand()
{
    qDebug() << "[INFO] Send Other Command!";
    switch (_cmdEnum)
    {
    case PROPERTY:
    {
        qDebug() << "[INFO] PROPERTY";
        cmd = read->getCommand(_cmdEnum);
        this->updateCRCByte(cmd);
        this->writeCommand(cmd, _cmdEnum);

        connect(mySerial, SIGNAL(completeRead()), this, SLOT(showData()));

        timeOut->stop();
    }
        break;

    case WRITE_MEMMORY:
    {
        qDebug() << "[INFO] WRITE_MEMMORY";

        cmd = read->getCommand(_cmdEnum);
        this->updateSizeData2Send(cmd);
        this->updateCRCByte(cmd);
        this->writeCommand(cmd, _cmdEnum);

        mySerial->_bResetTmp = true;
        connect(mySerial, SIGNAL(completeRead()), this, SLOT(showData()));
        timeOut->stop();
    }
        break;
    case SEND_DATA:
    {
        qDebug() << "[INFO] SEND_DATA";

        mySerial->_bResetTmp = true;
        writeData(get32ByteFromData(data, _indexBlock));
        connect(mySerial, SIGNAL(completeRead()), this, SLOT(showData()));

        timeOut->stop();
        if(_indexBlock % (block_data/100) == 0)
        {
            _iValueProcess++;
        }
    }
        break;
    default:
        break;
    }
}


QByteArray MainWindow::get32ByteFromData(QByteArray data, uint32_t index)
{
    int j;
    QByteArray data_tmp;
    uint32_t offset = index*32;
    if(_indexBlock < block_data)
    {
        _indexBlock++;
        for(j = 0; j < 32; j++)
        {
            data_tmp[j] = data[offset + j];
        }
    }
    else
    {
        for(j = 0; j < size_block_final; j++)
        {
            data_tmp[j] = data[offset + j];
        }
    }

    return data_tmp;
}

void MainWindow::showData()
{
    qDebug() << "[INFO] show Data on GUI";

    switch(_cmdEnum)
    {
    case PROPERTY:
    {
        this->sendACK();

        QString _str_Property;
        _str_Property += (QChar) (mySerial->S_Property_Package->S_Property->u_property_value & 0xFF);
        _str_Property += (QChar) (((mySerial->S_Property_Package->S_Property->u_property_value >> 8) & 0xFF) + 48);
        _str_Property += ".";
        _str_Property += (QChar) (((mySerial->S_Property_Package->S_Property->u_property_value >> 16) & 0xFF) + 48);
        _str_Property += ".";
        _str_Property += (QChar) (((mySerial->S_Property_Package->S_Property->u_property_value >> 24) & 0xFF) + 48);
        ui->txtVersion->setText(_str_Property);
        ui->listStatus->addItem("Get Property successful!");

        disconnect(mySerial, SIGNAL(completeRead()), this, SLOT(showData()));

        _cmdEnum = NONE;
        //timeOut->start();
    }
        break;
    case PING:
    {
        qDebug() << "[INFO] Case PING";
        QString _str_Protocol;

        _str_Protocol += (QChar) mySerial->S_Ping_Packet->S_Ping->u_pro_name;
        _str_Protocol += (QChar) (mySerial->S_Ping_Packet->S_Ping->u_pro_major + 48);
        _str_Protocol += ".";
        _str_Protocol += (QChar) (mySerial->S_Ping_Packet->S_Ping->u_pro_minor + 48);
        _str_Protocol += ".";
        _str_Protocol += (QChar) (mySerial->S_Ping_Packet->S_Ping->u_pro_bugfix + 48);

        qDebug() << "_str_Protocol" << _str_Protocol;
        ui->txtProtocol->setText(_str_Protocol);
        ui->listStatus->addItem("Ping done, Connect successful!");

        disconnect(mySerial, SIGNAL(completeRead()), this, SLOT(showData()));

        _cmdEnum = PROPERTY;
        timeOut->start();
    }
        break;
    case RESET:
    {
        qDebug() << "[INFO] Case RESET";

        delete read;
        read = NULL;

        delete mySerial;
        mySerial = NULL;
    }
        break;

    case FLASH_ERASE:
    {

    }
        break;

    case WRITE_MEMMORY:
    {
        this->sendACK();
        _cmdEnum = SEND_DATA;
        timeOut->start();
    }
        break;

    case FLASH_REGION:
    {
        this->sendACK();
        _cmdEnum = WRITE_MEMMORY;
        timeOut->start();
    }
        break;

    case SEND_DATA:
    {
        disconnect(mySerial, SIGNAL(completeRead()), this, SLOT(showData()));
        timeOut->start();
        ui->progressBar->setValue(_iValueProcess);
    }
        break;
    default:
        break;
    }
}

void MainWindow::writeCommand(CommandType *cmd, CommandEnum _typeENUM)
{
    QByteArray data = QByteArray::fromRawData((const char*)cmd->command, cmd->length);

    mySerial->writeData(data, _typeENUM);
}

void MainWindow::writeData(QByteArray data)
{
    QByteArray header;
    header[0] = 0x5a;
    header[1] = 0xa5;
    header[2] = 0x20;
    header[3] = 0x00;
    header[4] = 0x00;
    header[5] = 0x00;
    header += data;

    uint8_t *src = (uint8_t*) malloc(1024 *sizeof(uint8_t));
    uint16_t crc;
    uint32_t j;
    uint32_t Nsize = header.length() -2;

    for(j = 0; j < Nsize; j++)
    {
        if(j > 3)
            src[j] = header[j + 2];
        else
            src[j] = header[j];
    }

    crc = calCRC16(src, Nsize);
    //crc = qToBigEndian(crc);
    qDebug(" CRC: %x", crc);

    header[4] = (uint8_t) crc & 0xFF;
    header[5] = (uint8_t) (crc >> 8);

    mySerial->writeData(header, SEND_DATA);
}

QString MainWindow::converString(QByteArray qArr)
{
    int     index;
    QString strTmp;

    for(index = 0; index < qArr.length(); index++)
    {
        strTmp[index] = QChar(qArr[index]);
    }

    return strTmp;
}

void MainWindow::on_btConnect_clicked()
{
    qDebug() << "[INFO] Button connect/disconnect click";
    if(_bDisconnect == false)
    {
        _bDisconnect = true;

        read       = new ReadCommand();
        mySerial   = new MySerial();

        this->sendPINGCommand();

        ui->txtVersion->clear();
        ui->listStatus->addItem("Connecting...");
        ui->btConnect->setEnabled(true);
        ui->btConnect->setText("Disconnect");

        connect(mySerial, SIGNAL(continuePING()), this, SLOT(pingAgain()));
    }
    else
    {
        _bDisconnect = false;

        delete mySerial;
        mySerial = NULL;

        delete read;
        read = NULL;
        ui->btConnect->setText("Connect");
        ui->listStatus->addItem("Disconnect!");
        ui->txtProtocol->clear();
    }
}

void MainWindow::on_btReset_clicked()
{
    qDebug() <<"[INFO] Button Reset Click!";

    if(read != NULL && mySerial != NULL)
    {
        _cmdEnum = RESET;
        _bDisconnect = false;

        cmd = read->getCommand(_cmdEnum);
        this->updateCRCByte(cmd);
        this->writeCommand(cmd, _cmdEnum);
        ui->listStatus->addItem("Reset device!");
        ui->btConnect->setText("Connect");
        ui->listStatus->addItem("Disconnect!");

        connect(mySerial, SIGNAL(completeRead()), this, SLOT(showData()));

    }
    else
    {
        ui->listStatus->addItem("Erro! Not connected!");
    }
}

bool MainWindow::sendPINGCommand()
{
    bool result = mySerial->openSerialPort(ui->comboBox->currentText());
    if(result)
    {
        _cmdEnum    = PING;
        cmd = read->getCommand(_cmdEnum);
        this->writeCommand(cmd, _cmdEnum);
        connect(mySerial, SIGNAL(completeRead()), this, SLOT(showData()));

        return true;
    }
    else
    {
        // catch erro
        return false;
    }
}

void MainWindow::pingAgain()
{
    _cmdEnum    = PING;
    cmd = read->getCommand(_cmdEnum);
    this->writeCommand(cmd, _cmdEnum);
}

void MainWindow::sendACK()
{
    qDebug() << "[INFO] Send ACK!";
    QByteArray arr;
    arr[0] = 0x5a;
    arr[1] = 0xa1;
    mySerial->writeData(arr);
}

uint16_t MainWindow::calCRC16(const uint8_t *src, uint32_t lengthInBytes)
{
    uint32_t crc = 0;
    uint32_t j;
    for (j = 0; j < lengthInBytes; ++j)
    {
        uint32_t i;
        uint32_t byte = src[j];
        crc ^= byte << 8;
        for (i = 0; i < 8; ++i)
        {
            uint32_t temp = crc << 1;
            if (crc & 0x8000)
            {
                temp ^= 0x1021;
            }
            crc = temp;
        }

    }
    return crc;
}

void MainWindow::updateCRCByte(CommandType *cmd)
{
    uint8_t *src = (uint8_t*) malloc(1024 *sizeof(uint8_t));
    uint16_t crc;
    uint32_t j;
    uint32_t Nsize = cmd->length -2;
    for(j = 0; j < Nsize; j++)
    {
        if(j > 3)
            src[j] = cmd->command[j + 2];
        else
            src[j] = cmd->command[j];
    }

    crc = calCRC16(src, Nsize);
    //crc = qToBigEndian(crc);
    qDebug(" CRC: %x", crc);

    cmd->command[4] = (uint8_t) crc & 0xFF;
    cmd->command[5] = (uint8_t) (crc >> 8);
}


void  MainWindow::updateSizeData2Send(CommandType *cmd)
{
    uint16_t u_size_data_send = data.length();
    cmd->command[14] = (uint8_t) u_size_data_send & 0xFF;
    cmd->command[15] = (uint8_t) (u_size_data_send >> 8);
}

void MainWindow::on_btClearlog_clicked()
{
    ui->listStatus->clear();
}
